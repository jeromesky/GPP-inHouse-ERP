
//  --------------------------------------------------------------------
//  This file was concatenated (and most likely also cached and gzipped)
//  by TinyMCE CF GZIP, a ColdFusion based Javascript Concatenater,
//  Compressor, and Cacher for TinyMCE.
//  V1, Mon Feb 9 9:00:00 -0500 2009
//  
//  Copyright (c) 2009 Jules Gravinese (http://www.webveteran.com/)
//  
//  TinyMCE CF GZIP is licensed under LGPL license.
//  More details can be found here: http://tinymce.moxiecode.com/license.php
//  
//  The gzip functions were adapted and incorporated by permission
//  from Artur Kordowski's Zip CFC 1.2 : http://zipcfc.riaforge.org/
//
//  This uncompressed concatenated JS: 0.68 KB
//  --------------------------------------------------------------------

tinyMCE_GZ.start();tinyMCE_GZ.end();
